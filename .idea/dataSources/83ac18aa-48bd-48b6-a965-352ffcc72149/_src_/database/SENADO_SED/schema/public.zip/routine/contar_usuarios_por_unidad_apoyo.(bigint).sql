create function contar_usuarios_por_unidad_apoyo(id_ua bigint) returns bigint
LANGUAGE plpgsql
AS $$
DECLARE
	total_conteo_por_unidad_apoyo BIGINT;
BEGIN
	SELECT COUNT(ID_USUARIO) INTO total_conteo_por_unidad_apoyo FROM USUARIO WHERE ID_UNIDAD_APOYO = ID_UA;
    RETURN total_conteo_por_unidad_apoyo;
END;
$$;
