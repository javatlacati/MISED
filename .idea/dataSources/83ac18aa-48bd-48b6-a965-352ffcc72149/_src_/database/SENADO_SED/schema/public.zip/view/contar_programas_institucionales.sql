CREATE VIEW contar_programas_institucionales AS SELECT count(programa_institucional.id_programa_institucional) AS total_conteo
   FROM programa_institucional;
