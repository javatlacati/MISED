CREATE VIEW contar_usuarios AS SELECT count(usuario.id_usuario) AS total_conteo
   FROM usuario;
