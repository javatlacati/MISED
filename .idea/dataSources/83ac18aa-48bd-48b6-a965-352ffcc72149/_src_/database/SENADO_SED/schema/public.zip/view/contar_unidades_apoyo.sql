CREATE VIEW contar_unidades_apoyo AS SELECT count(unidad_apoyo.id_unidad_apoyo) AS total_conteo
   FROM unidad_apoyo;
