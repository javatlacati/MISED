create function contar_usuarios_por_organo_direccion_estrategica(id_ode bigint) returns bigint
LANGUAGE plpgsql
AS $$
DECLARE
	total_conteo_por_organo_direccion_estrategica BIGINT;
BEGIN
	SELECT COUNT(U.ID_USUARIO) INTO total_conteo_por_organo_direccion_estrategica FROM USUARIO U 
    INNER JOIN UNIDAD_APOYO UA ON U.ID_UNIDAD_APOYO = UA.ID_UNIDAD_APOYO
    INNER JOIN ORGANO_DIRECCION_ESTRATEGICA ODE ON UA.ID_ORGANO_DIRECCION_ESTRATEGICA = ODE.ID_ORGANO_DIRECCION_ESTRATEGICA
    WHERE ODE.ID_ORGANO_DIRECCION_ESTRATEGICA = ID_ODE;
    RETURN total_conteo_por_organo_direccion_estrategica;
END;
$$;
